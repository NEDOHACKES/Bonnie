# Bonfie → Horizon 26.3

## Converted from the supplied `bonfie-1.0.jar`

The source jar is a Fabric 1.20.1 Java mod. Its `fabric.mod.json` declares:

- Minecraft `1.20.1`
- Fabric Loader `>=0.15.0`
- Fabric API
- GeckoLib

Horizon 26.3 is a native Rust implementation and does not execute Fabric Java
classes. Horizon's current porting model is:

1. carry `assets/` and compatible `data/` into an `.hmod`;
2. declare registries in `data/bonfie/horizon/`;
3. implement Java behaviour as a Rust `.hnmod` native layer.

The carried assets include the original Bonfie textures, Bedrock/GeckoLib
geometry and animations, sounds, Russian/English language files and dialogue.

## Behaviour identified in the original jar

The Java classes include:

- Bonfie entity with mood, affection, face state, follow policy, home
  position, temporary sit/lie state, inventory and work state.
- Modes: Follow, Guard, Wander, Caretaker, Gather, Treasure.
- Follow policies: Passive, Hostile Only, All.
- Work kinds: Chop, Mine, Fish, Flower, Brew, Sort, Cook.
- AI goals for tree chopping, mining, fishing, flowers, honey, cooking,
  brewing, smelting, container sorting, treasure hunting, guarding,
  following and feeding.
- Dialogue, mood system, networking and multiple client GUI screens.

The native Rust file starts the state-machine port. The remaining Java-specific
AI, custom renderer/model submission, menus and interaction packets must be
wired to the exact Horizon hook/API revision used by the target instance.

This is deliberate: Horizon rejects native bundles built for another revision,
so a final native `.hnmod` must be pinned to the exact SDK revision selected by
the user's launcher.
